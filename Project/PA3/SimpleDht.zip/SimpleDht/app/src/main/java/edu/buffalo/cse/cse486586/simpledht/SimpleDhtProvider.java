package edu.buffalo.cse.cse486586.simpledht;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Formatter;
import java.util.HashMap;
import java.util.Iterator;
import java.util.PriorityQueue;

import android.content.ContentProvider;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.os.AsyncTask;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.widget.TextView;
import java.util.Arrays;
import java.util.Collections;

public class SimpleDhtProvider extends ContentProvider {

    private Uri buildUri(String scheme, String authority) {
        Uri.Builder uriBuilder = new Uri.Builder();
        uriBuilder.authority(authority);
        uriBuilder.scheme(scheme);
        return uriBuilder.build();
    }

    private String genHash(String input) throws NoSuchAlgorithmException {
        MessageDigest sha1 = MessageDigest.getInstance("SHA-1");
        byte[] sha1Hash = sha1.digest(input.getBytes());
        Formatter formatter = new Formatter();
        for (byte b : sha1Hash) {
            formatter.format("%02x", b);
        }
        return formatter.toString();
    }

    private static final String TAG = SimpleDhtProvider.class.getSimpleName();
    private static final String REMOTE_PORT0 = "11108";
    private static final String REMOTE_PORT1 = "11112";
    private static final String REMOTE_PORT2 = "11116";
    private static final String REMOTE_PORT3 = "11120";
    private static final String REMOTE_PORT4 = "11124";
    private static final String[] REMOTE_PORTS = {REMOTE_PORT0, REMOTE_PORT1, REMOTE_PORT2, REMOTE_PORT3, REMOTE_PORT4};
    private static final int SERVER_PORT = 10000;
    private ArrayList<String> exitedNode = new ArrayList<String>();
    private String pred = null;
    private String succ = null;
    private String self_port = null;
    private HashMap<String, String> token_port = new HashMap<String, String>();
    private Uri uri = buildUri("content", "edu.buffalo.cse.cse486586.groupmessenger2.provider");
    private String node_id = null;
    private ArrayList<String> file_list = new ArrayList<String>();



    @Override
    public boolean onCreate() {
        // TODO Auto-generated method stub
        TelephonyManager tel = (TelephonyManager) this.getContext().getSystemService(Context.TELEPHONY_SERVICE);
        String portStr = tel.getLine1Number().substring(tel.getLine1Number().length() - 4);
        final String myPort = String.valueOf((Integer.parseInt(portStr) * 2));
        self_port = portStr;

        try{
            node_id = genHash(self_port);
        }catch (NoSuchAlgorithmException e){
            e.printStackTrace();
        }

        for (String s: REMOTE_PORTS){
            try{
                int port = Integer.parseInt(s)/2;
                String str_port = String.valueOf(port);
                String token = genHash(str_port);
                token_port.put(token,str_port);
            }catch (NoSuchAlgorithmException e) {
                e.printStackTrace();
            }

        }

        Log.i(TAG, "onCreate - portID: "+portStr+"; portNumber: "+myPort);
        Log.i(myPort, "Hash Key of this node: " + node_id);


        try {
            ServerSocket serverSocket = new ServerSocket(SERVER_PORT);
            new ServerTask().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, serverSocket);

        } catch (IOException e) {
            Log.e(TAG, "Can't create a ServerSocket");
        }

        if (!self_port.equals("5554")) {
            Log.i(TAG,"Join request sent.");
            new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, self_port);

        } else {
            exitedNode.add(node_id);
            Log.i(TAG,"Node joint: 5554; Node list size: "+ exitedNode.size());
        }


        return false;
    }

    private class ServerTask extends AsyncTask<ServerSocket, String, Void> {


        @Override
        protected Void doInBackground(ServerSocket... sockets) {
            ServerSocket serverSocket = sockets[0];

            Socket sSocket;
            DataInputStream dis;
            String input;
            DataOutputStream dos;

            while (true){
                try{
                    sSocket = serverSocket.accept();
                    dis = new DataInputStream(sSocket.getInputStream());
                    dos = new DataOutputStream(sSocket.getOutputStream());
                    input = dis.readUTF();

                    Log.i("Sever Task", "The input is " + input);

                    String[] inputs = input.split("@");
                    String command = inputs[0];
                    Log.i("Sever Task", "The command is " + command);
                    if (command.equals("Join")){
                        String new_node = genHash(inputs[1]);

                        if (exitedNode.size() == 1){

                            exitedNode.add(new_node);
                            pred = new_node;
                            succ = new_node;

                            String update_msg = node_id + "@" + node_id + "@" + node_id + "-" + new_node;
//                            Log.i(self_port, "The update_msg is " + update_msg);
                            Log.i(self_port, "Ports updated pred is " + token_port.get(pred) + " succ is " + token_port.get(succ));
                            dos.writeUTF(update_msg);

                        }else {
                            exitedNode.add(new_node);
                            Collections.sort(exitedNode);


                            int pos = exitedNode.indexOf(new_node);

                            Log.i("Sever", "pos is " + pos);

                            if (pos == 0){

                                String pred_node = exitedNode.get(exitedNode.size()-1);
                                String succ_node = exitedNode.get(pos+1);

                                String res = "";

                                for (int i = 0; i < exitedNode.size(); i++){
                                    if (i == 0){
                                        res += exitedNode.get(0);
                                    }else {
                                        res = res + "-" + exitedNode.get(i);
                                    }
                                }



                                String update_msg = pred_node + "@" + succ_node + "@" + res;
                                dos.writeUTF(update_msg);
                                dos.flush();

                                String pred_port = token_port.get(pred_node);
                                String succ_port = token_port.get(succ_node);

                                Socket pred_socket = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),
                                        Integer.parseInt(pred_port)*2);
                                DataOutputStream pred_dos = new DataOutputStream(pred_socket.getOutputStream());
                                String pred_msg = "Update@succ@" + new_node;
                                pred_dos.writeUTF(pred_msg);
                                pred_dos.flush();
                                pred_dos.close();
                                pred_socket.close();

                                Socket succ_socket = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),
                                        Integer.parseInt(succ_port)*2);
                                DataOutputStream succ_dos = new DataOutputStream(succ_socket.getOutputStream());
                                String succ_msg = "Update@pred@" + new_node;
                                succ_dos.writeUTF(succ_msg);
                                succ_dos.flush();
                                succ_dos.close();
                                succ_socket.close();

                                for (String s : exitedNode){
                                    String port =token_port.get(s);

                                    if (!(port.equals("5554") || s.equals(new_node))){
                                        Socket node_socket = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),
                                                Integer.parseInt(port)*2);

                                        DataOutputStream node_dos = new DataOutputStream(node_socket.getOutputStream());

                                        String msg = "Port@" + res;
                                        node_dos.writeUTF(msg);
                                        node_dos.close();
                                        node_socket.close();
                                    }

                                }
                            }

                            else if (pos != (exitedNode.size()-1)){
                                String pred_node = exitedNode.get(pos-1);
                                String succ_node = exitedNode.get(pos+1);

                                String res = "";

                                for (int i = 0; i < exitedNode.size(); i++){
                                    if (i == 0){
                                        res += exitedNode.get(0);
                                    }else {
                                        res = res + "-" + exitedNode.get(i);
                                    }
                                }


                                String update_msg = pred_node + "@" + succ_node + "@" + res;
                                dos.writeUTF(update_msg);
                                dos.flush();

                                String pred_port = token_port.get(pred_node);
                                String succ_port = token_port.get(succ_node);

                                Socket pred_socket = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),
                                        Integer.parseInt(pred_port)*2);
                                DataOutputStream pred_dos = new DataOutputStream(pred_socket.getOutputStream());
                                String pred_msg = "Update@succ@" + new_node;
                                pred_dos.writeUTF(pred_msg);
                                pred_dos.flush();
                                pred_dos.close();
                                pred_socket.close();

                                Socket succ_socket = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),
                                        Integer.parseInt(succ_port)*2);
                                DataOutputStream succ_dos = new DataOutputStream(succ_socket.getOutputStream());
                                String succ_msg = "Update@pred@" + new_node;
                                succ_dos.writeUTF(succ_msg);
                                succ_dos.flush();
                                succ_dos.close();
                                succ_socket.close();

                                for (String s : exitedNode){
                                    String port =token_port.get(s);

                                    if (!(port.equals("5554") || s.equals(new_node))){
                                        Socket node_socket = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),
                                                Integer.parseInt(port)*2);

                                        DataOutputStream node_dos = new DataOutputStream(node_socket.getOutputStream());

                                        String msg = "Port@" + res;
                                        node_dos.writeUTF(msg);
                                        node_dos.close();
                                        node_socket.close();
                                    }

                                }

                            }else {

                                String pred_node = exitedNode.get(pos-1);
                                String succ_node = exitedNode.get(0);

                                String res = "";

                                for (int i = 0; i < exitedNode.size(); i++){
                                    if (i == 0){
                                        res += exitedNode.get(0);
                                    }else {
                                        res = res + "-" + exitedNode.get(i);
                                    }
                                }


                                String update_msg = pred_node + "@" + succ_node + "@" + res;
                                dos.writeUTF(update_msg);
                                dos.flush();

                                String pred_port = token_port.get(pred_node);
                                String succ_port = token_port.get(succ_node);

                                Socket pred_socket = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),
                                        Integer.parseInt(pred_port)*2);
                                DataOutputStream pred_dos = new DataOutputStream(pred_socket.getOutputStream());
                                String pred_msg = "Update@succ@" + new_node;
                                pred_dos.writeUTF(pred_msg);
                                pred_dos.flush();
                                pred_dos.close();
                                pred_socket.close();

                                Socket succ_socket = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),
                                        Integer.parseInt(succ_port)*2);
                                DataOutputStream succ_dos = new DataOutputStream(succ_socket.getOutputStream());
                                String succ_msg = "Update@pred@" + new_node;
                                succ_dos.writeUTF(succ_msg);
                                succ_dos.flush();
                                succ_dos.close();
                                succ_socket.close();

                                for (String s : exitedNode){
                                    String port =token_port.get(s);

                                    if (!(port.equals("5554") || s.equals(new_node))){
                                        Socket node_socket = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),
                                                Integer.parseInt(port)*2);

                                        DataOutputStream node_dos = new DataOutputStream(node_socket.getOutputStream());

                                        String msg = "Port@" + res;
                                        node_dos.writeUTF(msg);
                                        node_dos.close();
                                        node_socket.close();
                                    }

                                }
                            }
                            Log.i(self_port, "Node Join Done: List Size " + exitedNode.size());

                        }
                    }else if (command.equals("Update")){

                        if (inputs[1].equals("succ")){
                            succ = inputs[2];
                            Log.i(self_port, "Ports updated pred is " + token_port.get(pred) + " succ is " + token_port.get(succ));

                        }else {
                            pred = inputs[2];
                            Log.i(self_port, "Ports updated pred is " + token_port.get(pred) + " succ is " + token_port.get(succ));

                        }

                    }else if (command.equals("Insert")){
                        String key = inputs[1];
                        String value = inputs[2];
                        ContentValues contentValues = new ContentValues();
                        contentValues.put("key", key);
                        contentValues.put("value", value);
                        insert(uri, contentValues);
                    }else if (command.equals("Delete")){
                        if (inputs[1].equals("*")){
                            delete(uri, "@", null);
                        }else {
                            delete(uri, inputs[1], null);
                        }
                    }else if (command.equals("Query")){
                        if (inputs[1].equals("*")) {
                            String self_pair = "";
                            if (file_list.size() > 0){
                                StringBuilder stringBuilder1 = new StringBuilder();
                                for (String s : file_list){
                                    FileInputStream fis = getContext().openFileInput(s);
                                    InputStreamReader inputStreamReader = new InputStreamReader(fis, StandardCharsets.UTF_8);
                                    StringBuilder stringBuilder = new StringBuilder();
                                    BufferedReader reader = new BufferedReader(inputStreamReader);
                                    String line = reader.readLine();
                                    stringBuilder.append(line);
                                    String content = stringBuilder.toString();

                                    String pair = s + "-" + content + "@";
                                    stringBuilder1.append(pair);
                                }
                                self_pair = stringBuilder1.toString();
                            }
                            if (succ.equals(inputs[2])){
                                dos.writeUTF(self_pair);
                            }else {
                                String succ_port = token_port.get(succ);
                                Socket succ_s = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),
                                        Integer.parseInt(succ_port)*2);
                                DataOutputStream succ_dos = new DataOutputStream(succ_s.getOutputStream());
                                succ_dos.writeUTF(input);
                                DataInputStream succ_dis = new DataInputStream(succ_s.getInputStream());
                                String sucResult = succ_dis.readUTF();
                                String combineResult = self_pair + sucResult;
                                succ_dos.close();
                                succ_dis.close();
                                succ_s.close();

                                dos.writeUTF(combineResult);
                            }
                        }else {
                            String key = inputs[1];
                            Log.i("Sever query key", "the key is " + key);
                            if (file_list.contains(key)){
                                FileInputStream fis = getContext().openFileInput(key);
                                InputStreamReader inputStreamReader = new InputStreamReader(fis, StandardCharsets.UTF_8);
                                StringBuilder stringBuilder = new StringBuilder();
                                BufferedReader reader = new BufferedReader(inputStreamReader);

                                String line = reader.readLine();
                                stringBuilder.append(line);
                                String content = stringBuilder.toString();
                                String re = "Yes@" + content;
                                dos.writeUTF(re);
                            }else {
                                dos.writeUTF("No");
                            }

                        }
                    }else if (command.equals("Request")){
                        String result = "";
                        for (int i = 0; i < exitedNode.size(); i++){
                            if (i == 0) {
                                result += exitedNode.get(i);
                            }else {
                                String node = exitedNode.get(i);
                                result = result + "-" + node;
                            }
                        }
                        dos.writeUTF(result);

                    }else if (command.equals("Port")){
                        exitedNode.clear();
                        String[] ports = inputs[1].split("-");
                        Collections.addAll(exitedNode,ports);

                        Log.i("Sever port part", "Node list update Done: List Size " + exitedNode.size());
                    }

                    dis.close();
                    dos.close();
                    sSocket.close();

                }catch (IOException e){
                    e.printStackTrace();
                }catch (NoSuchAlgorithmException e){
                    e.printStackTrace();
                }

            }

        }
    }

    private class ClientTask extends AsyncTask<String, Void, Void> {


        @Override
        protected Void doInBackground(String... msgs) {

            try{
                Socket socket = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),
                        Integer.parseInt(REMOTE_PORT0));

                String msg_to_send = "Join" + "@" + msgs[0];
                DataOutputStream dos = new DataOutputStream(socket.getOutputStream());
                dos.writeUTF(msg_to_send);

                DataInputStream dis = new DataInputStream(socket.getInputStream());

                String updata_msg = dis.readUTF();
                Log.i("Client", "Msg form Sever " + updata_msg);
                String[] ports = updata_msg.split("@");
                pred = ports[0];
                succ = ports[1];
                String exited_nodes = ports[2];

                String[] nodes = exited_nodes.split("-");

                for (String node : nodes){
                    if (!exitedNode.contains(node)){
                        exitedNode.add(node);
                    }
                }

                Log.i("Client", "Join node list size " + exitedNode.size());

                Log.i("Client", "Ports updated pred is " + token_port.get(pred) + " succ is " + token_port.get(succ));

            }catch (UnknownHostException e) {
                Log.e(TAG, "ClientTask UnknownHostException");
            } catch (IOException e) {
                Log.e(TAG, "ClientTask socket IOException");
            }
            return null;
        }
    }


    @Override
    public int delete(Uri uri, String selection, String[] selectionArgs) {
        // TODO Auto-generated method stub
        try{
            if (pred == null && succ == null){
                if (selection.equals("@") || selection.equals("*")){
                    for (String s: file_list){
                        getContext().deleteFile(s);
                        file_list.remove(s);
                    }
                }else {
                    getContext().deleteFile(selection);
                    file_list.remove(selection);
                }
            }else {
                if (selection.equals("@")){
                    for (String s: file_list){
                        getContext().deleteFile(s);
                        file_list.remove(s);
                    }
                }else if (selection.equals("*")){

                    for (String s: file_list){
                        getContext().deleteFile(s);
                        file_list.remove(s);
                    }

                    for (String node: exitedNode){
                        String po = token_port.get(node);
                        if (!po.equals(self_port)){
                            Socket socket = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),
                                    Integer.parseInt(po)*2);

                            String msg_to_send = "Delete@*";
                            DataOutputStream dos = new DataOutputStream(socket.getOutputStream());
                            dos.writeUTF(msg_to_send);

                            dos.close();
                            socket.close();
                        }
                    }
                }else{
                    if (file_list.contains(selection)){
                        getContext().deleteFile(selection);
                        file_list.remove(selection);
                    }else {
                        String succ_port = token_port.get(succ);
                        Socket socket = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),
                                Integer.parseInt(succ_port)*2);

                        DataOutputStream dos = new DataOutputStream(socket.getOutputStream());
                        String msg_to_send = "Delete@" + selection;
                        dos.writeUTF(msg_to_send);
                        dos.flush();
                        dos.close();
                        socket.close();
                    }
                }
            }
        }catch (Exception e){
            Log.e("Delete failed: ", e.toString());
        }


        return 0;
    }

    @Override
    public String getType(Uri uri) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public Uri insert(Uri uri, ContentValues values) {
        // TODO Auto-generated method stub
        String key = values.getAsString("key");
        String value = values.getAsString("value");
        FileOutputStream outputStream;

        try{
            if (pred == null && succ == null) {
                file_list.add(key);
                outputStream = getContext().openFileOutput(key, Context.MODE_PRIVATE);
                outputStream.write(value.getBytes());
                outputStream.flush();
                outputStream.close();
            } else {
                String hashed_key = genHash(values.getAsString("key"));
                String hashed_curr = node_id;
                String hashed_pred = pred;

                if (hashed_curr.compareTo(hashed_pred) > 0 && hashed_key.compareTo(hashed_curr) <= 0 && hashed_key.compareTo(hashed_pred) > 0) {
                    file_list.add(key);
                    outputStream = getContext().openFileOutput(key, Context.MODE_PRIVATE);
                    outputStream.write(value.getBytes());
                    outputStream.flush();
                    outputStream.close();
                } else if (hashed_pred.compareTo(hashed_curr) > 0 && hashed_key.compareTo(hashed_pred) > 0) {
                    file_list.add(key);
                    outputStream = getContext().openFileOutput(key, Context.MODE_PRIVATE);
                    outputStream.write(value.getBytes());
                    outputStream.flush();
                    outputStream.close();
                } else if (hashed_pred.compareTo(hashed_curr) > 0 && hashed_key.compareTo(hashed_curr) <= 0) {
                    file_list.add(key);
                    outputStream = getContext().openFileOutput(key, Context.MODE_PRIVATE);
                    outputStream.write(value.getBytes());
                    outputStream.flush();
                    outputStream.close();
                } else {

                    String succ_port = token_port.get(succ);
                    Socket socket = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),
                            Integer.parseInt(succ_port) * 2);
                    String msg_to_send = "Insert" + "@" + key + "@" + value;
                    DataOutputStream dos = new DataOutputStream(socket.getOutputStream());
                    dos.writeUTF(msg_to_send);
                    dos.flush();
                    dos.close();
                    socket.close();

                }
            }
        }catch (Exception e){
            Log.e("Insert failed: ", e.toString());
        }
        return null;
    }



    @Override
    public Cursor query(Uri uri, String[] projection, String selection, String[] selectionArgs,
                        String sortOrder) {
        // TODO Auto-generated method stub
        String[] columnNames = {"key", "value"};
        MatrixCursor cursor = new MatrixCursor(columnNames);

        try{
            if (pred == null && succ == null) {
                if (selection.equals("*") || selection.equals("@")) {
                    for (String s : file_list) {
                        FileInputStream fis = getContext().openFileInput(s);
                        InputStreamReader inputStreamReader = new InputStreamReader(fis, StandardCharsets.UTF_8);
                        StringBuilder stringBuilder = new StringBuilder();
                        BufferedReader reader = new BufferedReader(inputStreamReader);

                        String line = reader.readLine();
                        stringBuilder.append(line);
                        String content = stringBuilder.toString();
                        String[] result = {s, content};
                        cursor.addRow(result);
                        fis.close();
                        inputStreamReader.close();
                        reader.close();
                    }
                } else {
                    FileInputStream fis = getContext().openFileInput(selection);
                    InputStreamReader inputStreamReader = new InputStreamReader(fis, StandardCharsets.UTF_8);
                    StringBuilder stringBuilder = new StringBuilder();
                    BufferedReader reader = new BufferedReader(inputStreamReader);

                    String line = reader.readLine();
                    stringBuilder.append(line);
                    String content = stringBuilder.toString();
                    String[] result = {selection, content};
                    cursor.addRow(result);
                    fis.close();
                    inputStreamReader.close();
                    reader.close();
                }

            }else {
                if (selection.equals("@")){
                    for (String s : file_list) {
                        FileInputStream fis = getContext().openFileInput(s);
                        InputStreamReader inputStreamReader = new InputStreamReader(fis, StandardCharsets.UTF_8);
                        StringBuilder stringBuilder = new StringBuilder();
                        BufferedReader reader = new BufferedReader(inputStreamReader);

                        String line = reader.readLine();
                        stringBuilder.append(line);
                        String content = stringBuilder.toString();
                        String[] result = {s, content};
                        cursor.addRow(result);
                        fis.close();
                        inputStreamReader.close();
                        reader.close();
                    }
                }else if (selection.equals("*")){
                    try{
                        String succ_port = token_port.get(succ);
                        Socket succ_s = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),
                                Integer.parseInt(succ_port)*2);
                        DataOutputStream succ_out = new DataOutputStream(succ_s.getOutputStream());
                        String msg_to_send = "Query@*@" + node_id;
                        succ_out.writeUTF(msg_to_send);

                        DataInputStream succ_in = new DataInputStream(succ_s.getInputStream());
                        String pairs = succ_in.readUTF();

                        String self_pair = "";
                        if (file_list.size() > 0){
                            StringBuilder stringBuilder1 = new StringBuilder();
                            for (String s : file_list){
                                FileInputStream fis = getContext().openFileInput(s);
                                InputStreamReader inputStreamReader = new InputStreamReader(fis, StandardCharsets.UTF_8);
                                StringBuilder stringBuilder = new StringBuilder();
                                BufferedReader reader = new BufferedReader(inputStreamReader);
                                String line = reader.readLine();
                                stringBuilder.append(line);
                                String content = stringBuilder.toString();

                                String pair = s + "-" + content + "@";
                                stringBuilder1.append(pair);
                            }
                            self_pair = stringBuilder1.toString();
                        }

                        String all_pairs = self_pair + pairs;

                        String[] each_pair = all_pairs.split("@");

                        if (each_pair.length > 0){
                            for (String str: each_pair){
                                String key = str.split("-")[0];
                                String content = str.split("-")[1];
                                String[] key_content = {key, content};
                                cursor.addRow(key_content);
                            }
                        }

                    }catch (IOException e){
                        e.printStackTrace();
                    }

                }else {
                    if (file_list.contains(selection)){
                        FileInputStream fis = getContext().openFileInput(selection);
                        InputStreamReader inputStreamReader = new InputStreamReader(fis, StandardCharsets.UTF_8);
                        StringBuilder stringBuilder = new StringBuilder();
                        BufferedReader reader = new BufferedReader(inputStreamReader);

                        String line = reader.readLine();
                        stringBuilder.append(line);
                        String content = stringBuilder.toString();
                        String[] result = {selection, content};
                        cursor.addRow(result);
                        fis.close();
                        inputStreamReader.close();
                        reader.close();
                    }else {

                        for (String node: exitedNode){
                            String po = token_port.get(node);
                            if (!po.equals(self_port)){
                                Socket socket = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),
                                        Integer.parseInt(po)*2);

                                String msg_to_send = "Query" + "@" + selection;
                                DataOutputStream dos = new DataOutputStream(socket.getOutputStream());
                                dos.writeUTF(msg_to_send);

                                DataInputStream dis = new DataInputStream(socket.getInputStream());
                                String result = dis.readUTF();
                                if (result.startsWith("Yes")){
                                    String content = result.split("@")[1];
                                    String[] add = {selection, content};
                                    cursor.addRow(add);
                                }
                                dos.close();
                                dis.close();
                                socket.close();
                            }
                        }
                    }
                }
            }
        }catch (Exception e) {
            Log.e("Query Failed", e.toString());
        }
        return cursor;
    }

    @Override
    public int update(Uri uri, ContentValues values, String selection, String[] selectionArgs) {
        // TODO Auto-generated method stub
        return 0;
    }


}
