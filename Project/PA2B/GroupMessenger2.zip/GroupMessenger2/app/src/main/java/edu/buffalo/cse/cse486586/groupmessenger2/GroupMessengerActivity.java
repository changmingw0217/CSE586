package edu.buffalo.cse.cse486586.groupmessenger2;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.telephony.TelephonyManager;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.PriorityQueue;
import java.io.FileOutputStream;

/**
 * GroupMessengerActivity is the main Activity for the assignment.
 * 
 * @author stevko
 *
 */
public class GroupMessengerActivity extends Activity {

    private static final String TAG = GroupMessengerActivity.class.getSimpleName();
    private static final String REMOTE_PORT0 = "11108";
    private static final String REMOTE_PORT1 = "11112";
    private static final String REMOTE_PORT2 = "11116";
    private static final String REMOTE_PORT3 = "11120";
    private static final String REMOTE_PORT4 = "11124";
    private static final String[]REMOTE_PORTS = {REMOTE_PORT0, REMOTE_PORT1, REMOTE_PORT2, REMOTE_PORT3, REMOTE_PORT4};
    private static final int SERVER_PORT = 10000;

    private int FIFO_seq = 0;
    private int TOTAL_seq = 0;

    private int self_port = Integer.MAX_VALUE;

    private HashMap<String,Boolean> Port_States = new HashMap<String,Boolean>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_group_messenger);

        Port_States.put(REMOTE_PORT0,true);
        Port_States.put(REMOTE_PORT1,true);
        Port_States.put(REMOTE_PORT2,true);
        Port_States.put(REMOTE_PORT3,true);
        Port_States.put(REMOTE_PORT4,true);

        /***
         * Code From PA1
         */
        TelephonyManager tel = (TelephonyManager) this.getSystemService(Context.TELEPHONY_SERVICE);
        String portStr = tel.getLine1Number().substring(tel.getLine1Number().length() - 4);
        final String myPort = String.valueOf((Integer.parseInt(portStr) * 2));
        self_port = Integer.parseInt(myPort);
        try {
            ServerSocket serverSocket = new ServerSocket(SERVER_PORT);
            new ServerTask().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, serverSocket);

        } catch (IOException e) {
            Log.e(TAG, "Can't create a ServerSocket");
            return;
        }

        /*
         * TODO: Use the TextView to display your messages. Though there is no grading component
         * on how you display the messages, if you implement it, it'll make your debugging easier.
         */
        final TextView tv = (TextView) findViewById(R.id.textView1);
        tv.setMovementMethod(new ScrollingMovementMethod());
        
        /*
         * Registers OnPTestClickListener for "button1" in the layout, which is the "PTest" button.
         * OnPTestClickListener demonstrates how to access a ContentProvider.
         */
        findViewById(R.id.button1).setOnClickListener(
                new OnPTestClickListener(tv, getContentResolver()));
        
        /*
         * TODO: You need to register and implement an OnClickListener for the "Send" button.
         * In your implementation you need to get the message from the input box (EditText)
         * and send it to other AVDs.
         */
        /***
         * Reference:https://developer.android.com/reference/android/widget/Button
         * Reference: PA1
         */
        final EditText editText = (EditText) findViewById(R.id.editText1);
        final Button button = (Button) findViewById(R.id.button4);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String msg = editText.getText().toString() + "\n";
                editText.setText("");

                new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, msg, myPort);
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.activity_group_messenger, menu);
        return true;
    }

    public class MessageHelper implements Comparable<MessageHelper>{
        String message;
        Integer fifo_seq;
        Integer port;
        Integer total_seq;
//        Integer suggesting_process;
        Boolean deliverable;

        public MessageHelper(String message, Integer fifo_seq, Integer port, Integer total_seq,Boolean deliverable){
            this.message = message;
            this.fifo_seq = fifo_seq;
            this.port = port;
            this.total_seq = total_seq;
//            this.suggesting_process = suggesting_process;
            this.deliverable = deliverable;
        }

        public void setDeliverable(boolean deliverable){
            this.deliverable = deliverable;
        }

        public void setTotal_seq(Integer total_seq){
            this.total_seq = total_seq;
        }

//        public void setSuggesting_process(Integer suggesting_process){
//            this.suggesting_process = suggesting_process;
//        }



        @Override
        public int compareTo(MessageHelper another) {

//            if(this.port.equals(another.port)){
//                return this.fifo_seq - another.fifo_seq;
//            }else if(this.total_seq.equals(another.total_seq)){
//                return this.suggesting_process - another.suggesting_process;
//            }
//            if (this.deliverable && !another.deliverable){
//                return 1;
//            }
//            if (!this.deliverable && another.deliverable){
//                return -1;
//            }
//            if (this.total_seq.equals(another.total_seq)){
//                return this.port - another.port;
//            }
////            if (this.total_seq.equals(another.total_seq) && this.suggesting_process.equals(another.suggesting_process)){
////                return this.port - another.port;
////            }
//            if (this.port.equals(another.port)){
//                return this.fifo_seq - another.port;
//            }
//
//            return this.total_seq - another.total_seq;
            if (!this.deliverable && another.deliverable){
                return -1;
            }else if (this.deliverable && !another.deliverable){
                return 1;
            }else{
                if (this.total_seq < another.total_seq){
                    return -1;
                }else if (this.total_seq > another.total_seq){
                    return 1;
                }else {
                    if (this.port < another.port){
                        return -1;
                    }else{
                        return 1;
                    }

                }
            }
//            if (!this.deliverable && another.deliverable){
//                return -1;
//            }else if (this.deliverable && !another.deliverable){
//                return 1;
//            }else{
//                if (this.fifo_seq < another.fifo_seq){
//                    return -1;
//                }else if (this.fifo_seq > another.fifo_seq){
//                    return 1;
//                }else {
//                    if (this.total_seq < another.total_seq){
//                        return -1;
//                    }else if (this.total_seq > another.total_seq){
//                        return 1;
//                    }else {
//                        if (this.port < another.port){
//                            return -1;
//                        }else {
//                            return 1;
//                        }
//                    }
//                }
//            }

        }
    }


    /***
     * Reference: https://developer.android.com/reference/java/util/PriorityQueue
     */

    private class ServerTask extends AsyncTask<ServerSocket, String, Void> {
        private int msg_count = 0;

        final TextView tv = (TextView) findViewById(R.id.textView1);
        OnPTestClickListener o = new OnPTestClickListener(tv, getContentResolver());

        private Uri uri = o.buildUri("content", "edu.buffalo.cse.cse486586.groupmessenger2.provider");

        private ContentResolver contentResolver = getContentResolver();

        PriorityQueue<MessageHelper> hold_back_queue = new PriorityQueue<MessageHelper>();


        @Override
        protected Void doInBackground(ServerSocket... sockets) {
            ServerSocket serverSocket = sockets[0];

            Socket sSocket;
            DataInputStream dis;
            String input;
            DataOutputStream dos;
            try{

                while(true){
                    sSocket = serverSocket.accept();// server starts listen to socket
                    dis = new DataInputStream(sSocket.getInputStream());
                    input = dis.readUTF();// stream read string

                    dos = new DataOutputStream(sSocket.getOutputStream());


                    String[] inputs = input.split("@");

//                    String msg_data = inputs[0];
//                    Log.i(TAG, " The input length is " + inputs.length);

                    if(inputs.length == 3){
                        TOTAL_seq++;

                        String TOTAL = Integer.toString(TOTAL_seq);

                        MessageHelper message = new MessageHelper(inputs[0],Integer.parseInt(inputs[1]), Integer.parseInt(inputs[2]), self_port,false);

                        hold_back_queue.add(message);

                        dos.writeUTF(TOTAL);
                        dos.flush();


                    }else if (inputs.length == 4) {
                        TOTAL_seq = Math.max(Integer.parseInt(inputs[2]), TOTAL_seq);

                        Iterator value = hold_back_queue.iterator();

                        while (value.hasNext()) {
                            MessageHelper message = (MessageHelper) value.next();
                            if (message.fifo_seq.equals(Integer.parseInt(inputs[0])) && message.port.equals(Integer.parseInt(inputs[1])) && !message.deliverable) {
                                String msg_content = message.message;
                                value.remove();
//                                message.setTotal_seq(Integer.parseInt(inputs[2]));
//                                message.setDeliverable(true);
//                                message.setSuggesting_process(Integer.parseInt(inputs[3]));
                                MessageHelper temp = new MessageHelper(msg_content, Integer.parseInt(inputs[0]), Integer.parseInt(inputs[1]), Integer.parseInt(inputs[2]), true);
                                hold_back_queue.add(temp);

                                break;
                            }
                        }
//                        while (hold_back_queue.size() != 0 && hold_back_queue.peek().deliverable) {
//
//                            MessageHelper p = hold_back_queue.poll();
////                            String debug = "The msg is " + p.message + " The msg fifo is " + p.fifo_seq + " The sender is " + p.port + " The suggest seq is " + p.total_seq;
//                            publishProgress(p.message);
////                            publishProgress(debug);
//                        }
                    }

                    else if (inputs.length == 2){
                        Port_States.remove(inputs[0]);
                        Port_States.put(inputs[0],false);
//                        Log.i(TAG, "Edit port state");
                        Iterator value = hold_back_queue.iterator();

                        while (value.hasNext()){
                            MessageHelper message = (MessageHelper) value.next();
                            if (message.port.equals(Integer.parseInt(inputs[0]))){
                                value.remove();
                            }
                        }

                    }

                    while (hold_back_queue.size() != 0 && hold_back_queue.peek().deliverable){

                        MessageHelper p = hold_back_queue.poll();
//                        String debug = "The msg is " + p.message + " The msg fifo is " + p.fifo_seq + " The sender is " + p.port + " The suggest seq is " + p.total_seq + " The suggest port is " + p.suggesting_process;
                        publishProgress(p.message);
//                        publishProgress(debug);
                    }

                    dos.close();
//                    publishProgress(msg_data);// trigger the execution of onProgressUpdate()
                    dis.close();// close stream
                    sSocket.close(); // close socket
                }

            } catch (UnknownHostException e) {
                Log.e(TAG, "ClientTask UnknownHostException");
            } catch (IOException e) {
                Log.e(TAG, "ServerTask IOException");
            }

            return null;
        }



        protected void onProgressUpdate(String...strings) {
            /*
             * The following code displays what is received in doInBackground().
             */
            String strReceived = strings[0].trim();
            TextView textView = (TextView) findViewById(R.id.textView1);
//            textView.append(strReceived + "\n");
            textView.append(strReceived + " The msg count is " + msg_count + "\n");
//            msg_count++;

            ContentValues contentValues = new ContentValues();
            contentValues.put("key",Integer.toString(msg_count));
            contentValues.put("value", strReceived);



//            GroupMessengerProvider gmp = new GroupMessengerProvider();
//
//            uri = gmp.insert(uri, contentValues);


            contentResolver.insert(uri, contentValues);

            FileOutputStream outputStream;

            try {
                outputStream = openFileOutput(Integer.toString(msg_count), Context.MODE_PRIVATE);
                outputStream.write(strReceived.getBytes());
                outputStream.close();
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }

            msg_count++;
            return;
        }
    }

    /***
     * Client Task
     */
    /***
     * References
     * https://developer.android.com/reference/java/net/Socket
     */
    private class ClientTask extends AsyncTask<String, Void, Void> {
        DataOutputStream dos;
        DataInputStream  dis;
//        ArrayList<String[]> TOTAL_seq_list = new ArrayList<String[]>();
        PriorityQueue<Integer> pd = new PriorityQueue<Integer>(REMOTE_PORTS.length, Collections.<Integer>reverseOrder());


        @Override
        protected Void doInBackground(String... msgs) {
            FIFO_seq++;

            for (String s : REMOTE_PORTS) {
                if (Port_States.get(s)){
                    try {


//                    String remotePort = s;

                        Socket socket = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),
                                Integer.parseInt(s));


                        String msgToSend = msgs[0] + "@" + FIFO_seq + "@" + msgs[1];
//                    Log.i(TAG, "Msg to seed is " + msgToSend);




                        dos = new DataOutputStream(socket.getOutputStream());
//                        socket.setSoTimeout(500);
//                        try{
//                            dos.writeUTF(msgToSend);
//                        }catch (SocketTimeoutException e){
//                            Log.i(TAG,"Filed got!!!!!!");
//                        }
                        dos.writeUTF(msgToSend);// stream send out data

                        dis = new DataInputStream(socket.getInputStream());

                        socket.setSoTimeout(500);
//                        try{
//                            String TOTAL_seq = dis.readUTF();
//                            pd.add(Integer.parseInt(TOTAL_seq));
//                        }catch (SocketTimeoutException e){
//                            Log.i(TAG,"Filed got!!!!!!");
//                        }

                        String TOTAL_seq = dis.readUTF();
//                    String[] TOTAL_port = TOTAL_seq.split("@");
//                    Log.i(TAG, "The B-D-1 msg is " + TOTAL_seq);

//                    TOTAL_seq_list.add(Integer.parseInt(TOTAL_seq));
                        pd.add(Integer.parseInt(TOTAL_seq));


//                    Log.i(TAG, "The total seq number is " + TOTAL_seq);
                        dis.close();// input stream close
                        dos.close();// output stream close
                        socket.close();// socket close

                    } catch (UnknownHostException e) {
                        Log.e(TAG, "ClientTask UnknownHostException");
                    } catch (IOException e) {
                        Port_States.remove(s);
                        Port_States.put(s, false);

                        for (String po: REMOTE_PORTS){
                            try{
                                if (Port_States.get(po)){
                                    Socket socket = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),
                                            Integer.parseInt(po));

                                    DataOutputStream dos = new DataOutputStream(socket.getOutputStream());

                                    dos.writeUTF(s + "@whatever");
                                    dos.close();

                                    socket.close();

                                }
                            } catch (UnknownHostException ex) {
                                ex.printStackTrace();
                            } catch (IOException ex) {
                                ex.printStackTrace();
                            }

                        }


                        Log.e(TAG, "ClientTask socket IOException");
                    }
                }


            }


//            Integer highest_total_seq = Collections.max(TOTAL_seq_list);
//            if(TOTAL_seq_list.size() == REMOTE_PORTS.length){
////                String[] result_total_seq_port = select(TOTAL_seq_list);
//                for(int i = 0; i < REMOTE_PORTS.length; i++){
//                try{
//                    String remotePort = REMOTE_PORTS[i];
//
//                    Socket socket = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),
//                            Integer.parseInt(remotePort));
//
//                    String seq_info = FIFO_seq + "@" + msgs[1] + "@" + result_total_seq_port[0] + "@" +result_total_seq_port[1];
//
//                    dos = new DataOutputStream(socket.getOutputStream());
//                    dos.writeUTF(seq_info);
//                    dos.flush();
////                    Log.i(TAG, "The seq info is " + seq_info);
//                    dos.close();
//                    socket.close();
//
//
//                } catch (UnknownHostException e) {
//                    Log.e(TAG, "ClientTask UnknownHostException");
//                } catch (IOException e) {
//                    Log.e(TAG, "ClientTask socket IOException");
//                }
//            }
//            }

//            Log.i(TAG + "Client", "The result seq is " + result_total_seq_port[0] + " The result port is " + result_total_seq_port[1]);
            Integer result_total_seq_port = pd.peek();
            for (String port : REMOTE_PORTS) {
                if (Port_States.get(port)){

                    try {
//                    String remotePort = port;

                        Socket socket = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),
                                Integer.parseInt(port));

                        String seq_info = FIFO_seq + "@" + msgs[1] + "@" + result_total_seq_port + "@whatever";

                        dos = new DataOutputStream(socket.getOutputStream());
                        dos.writeUTF(seq_info);
                        dos.flush();
//                    Log.i(TAG, "The seq info is " + seq_info);
                        dos.close();
                        socket.close();


                    } catch (UnknownHostException e) {
                        Log.e(TAG, "ClientTask UnknownHostException");
                    } catch (IOException e) {
                        Port_States.remove(port);
                        Port_States.put(port, false);

                        for (String po: REMOTE_PORTS){
                            try{
                                if (Port_States.get(po)){
                                    Socket socket = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),
                                            Integer.parseInt(po));

                                    DataOutputStream dos = new DataOutputStream(socket.getOutputStream());

                                    dos.writeUTF(port + "@whatever");
                                    dos.close();

                                    socket.close();

                                }
                            } catch (UnknownHostException ex) {
                                ex.printStackTrace();
                            } catch (IOException ex) {
                                ex.printStackTrace();
                            }

                        }

                        Log.e(TAG, "ClientTask socket IOException");
                    }
                }

            }

            return null;
        }

//        private String[] select(ArrayList<String[]> input){
//            String[] first = input.get(0);
//            Integer result_total = Integer.parseInt(first[0]);
//            Integer result_port = Integer.parseInt(first[1]);
//            for (int i = 1; i < input.size(); i++){
//                String[] temp = input.get(i);
//                Integer total_seq = Integer.parseInt(temp[0]);
//                Integer port = Integer.parseInt(temp[1]);
//
//                if(total_seq > result_total){
//                    result_total = total_seq;
//                    result_port = port;
//                }else if(total_seq == result_total && result_port > port){
//                    result_total = total_seq;
//                    result_port = port;
//                }
//
//            }
//
//            String[] result = {Integer.toString(result_total), Integer.toString(result_port)};
//            return result;
//        }

    }
}
